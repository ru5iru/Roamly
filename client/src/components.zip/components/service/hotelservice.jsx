import "service.scss";

const HotelService = () => {
    return (
        <div className="Service">
        </div>
    )
}

export default HotelService;