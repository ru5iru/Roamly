import { Link } from "react-router-dom";
import "./service.scss";
import Shops from "../../assets/images/shops.png";

const ShopService = () => {
    return (
        <div className="service">
            
            <Link to="/Shop">Shop</Link>
            <img src={Shops} alt="Shop Services" />
            <span className="blur-background">
                <h3>Shops</h3>
            </span>
        </div>
    )
}

export default ShopService;